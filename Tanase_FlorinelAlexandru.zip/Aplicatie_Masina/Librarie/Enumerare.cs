﻿//Florinel Alexandru Tanase,3123a
using System;
using System.Collections.Generic;
using System.Text;

namespace Librarie
{
    
    public enum Grup
    {
        Alb=0,
        Albastru=1,
        Violet=2,
        Negru=3,
        Rosu=4,
        Gri=5,
        Portocaliu=6,
        Verde=7,
        Auriu=8,
        Culoare_neselectata=9
    };

    public enum CampuriMasina
    {
         ID = 0,
         NUMEV = 1,
         NUMEC = 2,
         MARCA = 5,
         MODEL = 3,
         CULOARE = 6,
         PRET = 4,
         ANF = 7,
         DOT = 8,
         DATA_TRANZACTIE = 9,
         DATA_ACTUALIZARE = 10
}

}
