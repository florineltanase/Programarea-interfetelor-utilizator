﻿//Florinel Alexandru Tanase,3123a
using System;
using System.Collections.Generic;
using System.Text;

namespace Librarie

{
    public enum Culori
    {
        negru = 1,
        alb = 2,
        albastru = 3,
        argintiu = 4,
        galben = 5,
        gri = 6,
        portocaliu = 7,
        bej = 8,
        verde = 9,
        rosu = 10,
        maro = 11,
        random = 12,
    };
}
